package pkwork;

public class Text {
    public static void main(String[] args) {
        Game game = new Game();
        System.out.println(game.getNpc());
    }
}
